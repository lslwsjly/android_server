define({
  "name": "API文档",
  "version": "1.0.0",
  "description": "提供人：李思良",
  "title": "API文档",
  "url": "http://localhost:8080/",
  "generator": {
    "version": "0.8.2",
    "time": "2014-12-19T12:41:04.507Z"
  },
  "apidoc": "0.2.0"
});