define({
  "name": "rest API文档",
  "version": "1.0.0",
  "description": "提供人：李思良",
  "title": "rest API",
  "url": "http://localhost:8080/",
  "generator": {
    "version": "0.8.2",
    "time": "2014-12-20T03:03:16.372Z"
  },
  "apidoc": "0.2.0"
});